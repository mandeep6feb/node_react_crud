const config = {
    db: {
        host: "localhost",
        port: "380",
        user: "root",
        password: "",
        database: "my_balance"
    },
    listPerPage: 10,
  };
  module.exports = config;