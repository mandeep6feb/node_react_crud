const BL_USERS = "bl_users";
const WALLET = "wallet";
const CUSTOMERS = "customers";

module.exports = {
    BL_USERS,
    WALLET,
    CUSTOMERS
}
